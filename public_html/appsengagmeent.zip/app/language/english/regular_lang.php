<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang["Schedule"] = "Schedule";
$lang["schedule_on"] = "Schedule On";
$lang["scheduled_orders"] = "Scheduled orders";
$lang["schedule_order"] = "Schedule order";
$lang["schedule_order"] = "Schedule order";
$lang["time_date_and_time"] = "Time (Date and time)";
$lang["Detail"]             = "Detail";
$lang["schedule_detail"]             = "You can create a order and schedule it to publish on your account in the future. <br><br>Keep in mind that all times for scheduling correspond to your current time zone.";