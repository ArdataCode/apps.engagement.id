<?php 
// $route['admin']       = 'admin/auth/login';