<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$autoload['helper'] = ['admin'];
$autoload['config'] = [''];
$autoload['language'] = array('common');
$autoload['model'] = array('');
