<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class file_manager_model extends MY_Model 
{

    protected $tb_main;

    public function __construct()
    {
        parent::__construct();

    }
}
